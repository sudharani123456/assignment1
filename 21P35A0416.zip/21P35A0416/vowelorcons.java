import java.util.Scanner;
class vowelorcons {
    public static void main(String args[])
    {
        Scanner scanner=new Scanner(System.in);
        System.out.print("please enter a alphabet:");
        char ch=scanner.next().charAt(0);
        switch(ch){
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
              System.out.println("It's a VOWEL!");
              break;
            default:
             System.out.println("It's a consonant");

        }
    }
    
}
